class Reservation extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        
      };
  
      this.handleInputChange = this.handleInputChange.bind(this);
    }
  
    handleInputChange(event) {
      
    }
  
    render() {
      return (
        <form>
          
        </form>
      );
    }
  }
  
  ReactDOM.render(
    <Reservation />,
    document.getElementById('root')
  );
  